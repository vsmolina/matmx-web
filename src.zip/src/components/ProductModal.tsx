'use client'

import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import Image from 'next/image'
import Link from 'next/link'

interface Product {
  id?: number
  name: string
  sku: string
  vendor: string
  stock: number
  reorder_threshold: number
  unit_price: number
  category: string
  notes?: string
}

interface Vendor {
  id: number
  name: string
}

interface Props {
  mode: 'add' | 'edit'
  defaultValues?: Product
  onSave: () => void
  trigger: React.ReactNode
}

export default function ProductModal({ mode, defaultValues, onSave, trigger }: Props) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { isSubmitting },
    setValue,
  } = useForm<Product>({
    defaultValues: defaultValues || {
      name: '',
      sku: '',
      vendor: '',
      stock: 0,
      reorder_threshold: 0,
      unit_price: 0,
      category: '',
      notes: '',
    },
  })

  const [vendors, setVendors] = useState<Vendor[]>([])

  useEffect(() => {
    if (defaultValues) reset(defaultValues)
  }, [defaultValues, reset])

  useEffect(() => {
    async function fetchVendors() {
      try {
        const res = await fetch('http://localhost:4000/api/vendors', { credentials: 'include' })
        const data = await res.json()
        setVendors(data.vendors || [])
      } catch (err) {
        console.error('Failed to load vendors', err)
      }
    }
    fetchVendors()
  }, [])

  const onSubmit = async (data: Product) => {
    try {
      const res = await fetch(
        mode === 'add'
          ? 'http://localhost:4000/api/inventory'
          : `http://localhost:4000/api/inventory/${defaultValues?.id}`,
        {
          method: mode === 'add' ? 'POST' : 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(data),
        }
      )

      if (!res.ok) throw new Error('Failed to save product')
      toast.success(`Product ${mode === 'add' ? 'created' : 'updated'} successfully`)
      onSave()
    } catch (err) {
      console.error(err)
      toast.error('Error saving product')
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add New Product' : 'Edit Product'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <Input {...register('name')} placeholder="Name" required />
          <Input {...register('sku')} placeholder="SKU" required />

          <div className="flex gap-2 items-center">
            <select
              className="flex-1 border rounded px-3 py-2 text-sm"
              {...register('vendor')}
              defaultValue={defaultValues?.vendor || ''}
            >
              <option value="">-- Select Vendor --</option>
              {vendors.map((v) => (
                <option key={v.id} value={v.name}>{v.name}</option>
              ))}
            </select>
            <Link href="/admin/vendors">
              <Button type="button" variant="outline" size="sm">Create New</Button>
            </Link>
          </div>
          <hr className="h-px my-8 bg-black border-0 dark:bg-gray-700"></hr>
          <div className='text-sm pl-2'>Initial Stock</div>
          <Input type="number" {...register('stock')} placeholder="0" required />
          <div className='text-sm pl-2'>Reorder Threshhold</div>
          <Input type="number" {...register('reorder_threshold')} placeholder="0" required />
          <div className='text-sm pl-2'>Unit Price</div>
          <Input type="number" step="0.01" {...register('unit_price')} placeholder="0" required />
          <Input {...register('category')} placeholder="Category" />
          <Input {...register('notes')} placeholder="Notes" />

          <Button type="submit" disabled={isSubmitting}>
            {mode === 'add' ? 'Create' : 'Update'}
          </Button>
        </form>

        {mode === 'edit' && defaultValues?.id && (
          <div className="mt-6 border-t pt-4 text-center">
            <p className="text-sm text-gray-600 mb-2">Barcode Preview</p>
            <img
              src={`http://localhost:4000/api/inventory/${defaultValues.id}/barcode.png`}
              onError={(e) => {
                const target = e.target as HTMLImageElement
                target.alt = 'Barcode not available'
              }}
              alt="Barcode"
              className="mx-auto border bg-white p-2"
              width={300}
              height={80}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
