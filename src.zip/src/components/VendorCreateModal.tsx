'use client'

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { useState } from 'react'

interface Props {
  onSaved: () => void
  trigger: React.ReactNode
}

interface FormValues {
  name: string
  contact_name?: string
  email?: string
  phone?: string
  website?: string
  notes?: string
}

export default function VendorCreateModal({ onSaved, trigger }: Props) {
  const [open, setOpen] = useState(false)
  const {
    register,
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = useForm<FormValues>()

  const onSubmit = async (data: FormValues) => {
    try {
      const res = await fetch(`http://localhost:4000/api/vendors`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })

      if (!res.ok) throw new Error('Failed to create vendor')

      toast.success('Vendor created')
      setOpen(false)
      reset()
      onSaved()
    } catch (err) {
      console.error(err)
      toast.error('Failed to create vendor')
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Vendor</DialogTitle>
        </DialogHeader>

        <form className="space-y-4 mt-4" onSubmit={handleSubmit(onSubmit)}>
          <Input {...register('name')} placeholder="Vendor Name" required />
          <Input {...register('contact_name')} placeholder="Contact Name (optional)" />
          <Input {...register('email')} placeholder="Email (optional)" />
          <Input {...register('phone')} placeholder="Phone (optional)" />
          <Input {...register('website')} placeholder="Website (optional)" />
          <Input {...register('notes')} placeholder="Notes (optional)" />
          <Button type="submit" disabled={isSubmitting}>
            Save Vendor
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
